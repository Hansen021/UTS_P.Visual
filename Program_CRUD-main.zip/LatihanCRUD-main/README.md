# LatihanCRUD

STEPHEN PRATAMA KURNIA

TI.22.A5 312210635


![79uDuTgt6c](https://github.com/user-attachments/assets/725b10b1-45d5-4d77-b999-e58dcf0de530)
